package com.garry.foodapp;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SixthActivity extends AppCompatActivity implements  FragmentAInterface{

    public static int counter = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sixth);
    }

    @Override
    public void onButtonClicks(int x) {
        FragmentB fragmentB = (FragmentB) getFragmentManager().findFragmentById(R.id.fragment_b);
        fragmentB.setImage(getImageResource(x));
    }

    public int getImageResource(int ref) {
        switch (ref) {
            case 0:
                return R.drawable.img1;
            case 1:
                return R.drawable.img2;
            case 2:
                return R.drawable.img3;
            case 3:
                return R.drawable.img4;
            case 4:
                return R.drawable.img5;
            case 5:
                return R.drawable.img6;
            case 6:
                return R.drawable.img7;
            case 7:
                return R.drawable.img8;
            case 8:
                return R.drawable.img9;
            case 9:
                return R.drawable.img10;
            default:
                return R.drawable.img1;


        }
    }
}
