package com.garry.foodapp;

/**
 * Created by Garry on 5/11/2016.
 */
public interface FragmentAInterface {
    public void onButtonClicks(int x);
}
