package com.garry.foodapp;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by Garry on 5/11/2016.
 */
public class FragmentA extends Fragment {

    Button next, back;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_a, container, false);

        next = (Button) v.findViewById(R.id.button10);
        back = (Button) v.findViewById(R.id.button8);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SixthActivity sixthActivity = (SixthActivity) getActivity();
                sixthActivity.onButtonClicks(SixthActivity.counter++);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SixthActivity sixthActivity = (SixthActivity) getActivity();
                sixthActivity.onButtonClicks(SixthActivity.counter--);
            }
        });

        return v;
    }


}
