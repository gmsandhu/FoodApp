package com.garry.foodapp;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    TextView textView7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

    }

    public void mapIt(View view) {
        Intent intent=new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:39.0090642,-76.8916707"));
        Intent chooser=Intent.createChooser(intent,"Launch Maps");
        startActivity(chooser);
    }


    public void shareText(View view) {
//        Intent intent = new Intent(Intent.ACTION_SEND);
//        intent.setData(Uri.parse("mailto:"));
//        String to[] = {"garrysandhu4@gmail.com", "vivianaranha@yahoo.com", "gmsandhu400@gmail.com"};
//        intent.putExtra(Intent.EXTRA_EMAIL, to);
//        intent.putExtra(Intent.EXTRA_SUBJECT, "About Restaurant");
//        intent.putExtra(Intent.EXTRA_TEXT, "Garry's restaurant @ Greenbelt - http://www.google.com ");
//        intent.setType("message/rfc822");
//        Intent chooser = Intent.createChooser(intent, "Share About Us");
//        startActivity(chooser);

        textView7= (TextView) findViewById(R.id.textView7);
        String str = "Garry's restaurant @ Greenbelt - http://www.google.com ";
        Intent intent=new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT,str);
        Intent chooser=Intent.createChooser(intent,"Share Text");
        startActivity(chooser);
    }

    public void openMail(View view) {

    }

    public void openWebsite(View view) {
        Intent intent=new Intent(this,ThirdActivity.class);
        TextView googleUrl = (TextView) findViewById(R.id.textView7);
        intent.putExtra("GoogleURL",googleUrl.getText());
        startActivity(intent);

    }
}
