package com.garry.foodapp;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        Intent intent;
        switch (item.getItemId()) {
            case R.id.action_prefrences:
                intent=new Intent(this,FifthActivity.class);
                startActivity(intent);
                break;

            case R.id.action_gallery:
                intent=new Intent(this,SixthActivity.class);
                startActivity(intent);
                break;

            default:
                break;


        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);

    }

    public void contactUs(View view) {
        Intent intent=new Intent(this,SecondActivity.class);
        startActivity(intent);
    }

    public void openWebsite(View view) {
        Uri uri = Uri.parse("http://www.google.com");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }

    public void openMenu(View view) {
        Intent intent=new Intent(this,ForthActivity.class);
       startActivity(intent);
    }

    public void prefrences(View view) {
        Intent intent=new Intent(this,FifthActivity.class);
        startActivity(intent);
    }

    public void openPreference(){

    }

    public void gallery(View view) {
        Intent intent=new Intent(this,SixthActivity.class);
        startActivity(intent);
    }
}
