package com.garry.foodapp;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

/**
 * Created by Garry on 5/11/2016.
 */
public class FragmentB extends Fragment {

    public static int counterB = 0;

    ImageView iv;

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_b, container, false);

        iv = (ImageView) v.findViewById(R.id.imageView2);
        SixthActivity sa = new SixthActivity();
        setImage(sa.getImageResource(counterB));

        return v;
    }

    public void setImage(int img){
        iv.setImageResource(img);
    }
}